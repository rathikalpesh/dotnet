﻿using var connection=new Microsoft.Data.Sqlite.SqliteConnection();
connection.ConnectionString="Filename=Employee.db";
connection.Open();
using var command=connection.CreateCommand();
command.CommandText="SELECT Emp_id, Emp_name, salary, Commission FROM Employee";
using var DataReader=command.ExecuteReader();
while(DataReader.Read())
    Console.WriteLine("{0,-8}{1,10}{2,12:0.00}{3,9:0.00}",DataReader.GetInt32(0),DataReader.GetString(1),DataReader.GetDecimal(2),DataReader.GetDecimal(3));

