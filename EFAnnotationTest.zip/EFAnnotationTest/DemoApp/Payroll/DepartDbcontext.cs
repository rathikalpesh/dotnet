global using Microsoft.EntityFrameworkCore;
namespace DemoApp.Payroll;


public class DepartDbContext: DbContext
{

    public DbSet<Department> Department {get;set;}
    public DbSet<Employee> Employee {get;set;}

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=(localdb)\\DACIIT;Database=Employees");

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>()
                    .Property(p=>p.Id)
                    .HasColumnName("DepNo");
        modelBuilder.Entity<Employee>()
                    .Property(p=>p.Id)
                    .HasColumnName("EmpNo");
        modelBuilder.Entity<Employee>()
                    .Property(p=>p.DepartmentId)
                    .HasColumnName("DepNo");
    }




}