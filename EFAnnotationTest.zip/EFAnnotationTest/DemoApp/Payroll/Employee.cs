namespace DemoApp.Payroll;
public class Employee 
{
    public int Id{get;set;}
    public string EmpName{get;set;}
    public decimal Salary {get;set;}
    public decimal Comm {get;set;}
    public int DepartmentId {get;set;}
    
}