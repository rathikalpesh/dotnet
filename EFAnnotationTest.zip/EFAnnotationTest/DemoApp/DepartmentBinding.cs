using System.ComponentModel;

namespace DemoApp;
using Payroll;

public class DepartmentBinding : INotifyPropertyChanged
{
    public DepartDbContext _db=new DepartDbContext();
    public Department _currentDepartment;
    public IEnumerable<Department> Departments=>_db.Department.ToList();
    public event PropertyChangedEventHandler PropertyChanged;

    public Department CurrentDepartment
    {
        get=> _currentDepartment;
        set
        {
            _currentDepartment=value;
            _db.Entry(_currentDepartment).Collection(p=>p.Employees).Load();
            PropertyChanged?.Invoke(this , new PropertyChangedEventArgs("CurrentDepartment"));
        }

    }
}