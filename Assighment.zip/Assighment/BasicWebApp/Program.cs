﻿using BasicWebApp.Services;
using BasicWebApp.Controllers;


var builder=WebApplication.CreateBuilder();
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<ISimpleInterest,SimpleInterest>();
var app=builder.Build();
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();