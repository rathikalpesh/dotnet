namespace BasicWebApp.Services;

public interface ISimpleInterest
{
    double Calculate(double Amount, double Rate, int Period);
}