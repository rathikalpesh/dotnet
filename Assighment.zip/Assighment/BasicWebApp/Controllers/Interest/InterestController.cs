namespace BasicWebApp.Controllers;
using Services;
public class InterestController : Controller
{
     [HttpPost]   
    public IActionResult Index(double Amount, double Rate, int Period,ISimpleInterest Interest)
    {

          ViewBag.interest=Interest.Calculate(Amount,Rate,Period);
          return View("Calculate"); 
            
    }

}